package com.nfcs.leavemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
